package con1;


import java.sql.*;
//package con1;


public class Con1 {

    
    public static void main(String[] args){
        try{
             Class.forName("com.mysql.jdbc.Driver");  
            Connection con=DriverManager.getConnection(  
            "jdbc:mysql://localhost:3306/test1","root","");  
            System.out.println("Connection successfull");
            Statement stmt=con.createStatement();  
            ResultSet rs=stmt.executeQuery("select * from emp");
            
            System.out.println("Existing records in table:");
            System.out.println("Name\t\tAge");
            while(rs.next()){
                System.out.print(rs.getString(1));
                System.out.print("\t");
                System.out.println(rs.getInt(2));
            }

            con.close();  
        }
        catch(Exception e){ 
            System.out.println(e);
        }  
      


        
        
     
}}