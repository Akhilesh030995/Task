package com.springrest.springrest.entities;

public class Course {
	
	private long id;
	private String title;
	private String description;
	
	
	public Course(long id, String title, String description) {
		super();
//		System.out.println("get courses 11");
		this.id = id;
		this.title = title;
		this.description = description;
	}


	public Course() {
		super();
//		System.out.println("get courses 2");
		// TODO Auto-generated constructor stub
	}


	public long getId() {
//		System.out.println("get courses 4");
		return id;
	}


	public void setId(long id) {
//		System.out.println("get courses 5");
		this.id = id;
	}


	public String getTitle() {
//		System.out.println("get courses 6");
		return title;
	}


	public void setTitle(String title) {
//		System.out.println("get courses 7");
		this.title = title;
	}


	public String getDescription() {
//		System.out.println("get courses 8");
		return description;
	}


	public void setDescription(String description) {
//		System.out.println("get courses 9");
		this.description = description;
	}


	@Override
	public String toString() {
//		System.out.println("get courses 10");
		return "Course [id=" + id + ", title=" + title + ", description=" + description + "]";
	}
	
	
	
	

}
