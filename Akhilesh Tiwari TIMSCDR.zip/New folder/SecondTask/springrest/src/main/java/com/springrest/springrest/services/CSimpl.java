package com.springrest.springrest.services;

import java.util.ArrayList;

import java.util.List;

import org.springframework.stereotype.Service;

import com.springrest.springrest.entities.Course;

@Service

public class CSimpl implements CS {

	List<Course> list;
	
	public CSimpl() {
	//	System.out.println("get courses 12");
		
		list=new ArrayList<>();
		list.add(new Course(101,"Java","Core Java"));
		list.add(new Course(102,"C++","OOP"));
	}
	
	@Override
	public List<Course> getCourses() {
	//	System.out.println("get courses 14");
		// TODO Auto-generated method stub
		return list;
	} 
	public int setCourses(Course course) {
	//	System.out.println("get courses 14");
		// TODO Auto-generated method stub
		System.out.println("in set 2");
		
	
		System.out.println(course);
		
		return 1;
	} 

}
