package com.springrest.springrest.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springrest.springrest.entities.Course;
import com.springrest.springrest.services.CS;
import com.springrest.springrest.services.CSimpl;

@RestController 
public class MyController {
	
	@Autowired
	private CS css;
//	private CSimpl css;

	/* @GetMapping("/home")
	public String courses() {
		return "This is home page";
	} */
	
	@GetMapping("/courses")
	public List<Course> getCourses()
	{
//		System.out.println("get courses 1");
//		css = new CSimpl();
		return this.css.getCourses();
		
	}
	
	@PostMapping(value = "/courses", consumes = "application/json", produces = "application/json")
	public List<Course> createPerson(Course course) {
		System.out.println("post mapping 1");
		CSimpl csimp = new CSimpl();
	    csimp.setCourses(course);
	    return this.css.getCourses();
//	    return 1;
	}
	
}


